def add(a, b):
	return a+b

def sub(a, b):
	return a-b

def mul(a, b):
	return a*b

min_quantity=5

class stock_value:
	def cal(self, price):
		return min_quantity*price